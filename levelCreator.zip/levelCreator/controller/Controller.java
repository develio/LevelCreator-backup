package levels.editor.levelCreator.controller;

import java.io.InputStream;
import java.util.Scanner;

import game.model.level.Difficulty;
import game.model.level.Level;
import game.model.level.LevelFileManager;
import game.model.map.Map;
import levels.editor.levelCreator.model.LevelCreator;
import levels.editor.levelCreator.view.View;

public final class Controller {
    private final LevelCreator levelCreator;
    private final View view;
    private final Scanner scanner;
    private final InputStream inputStream = System.in;
    private String[] mapFiles = null;
    private String mapFile = null;
    private String levelName = null;
    private Difficulty difficulty = null;
    private String errorMessage = null;
    private Level level = null;
    
    public Controller(LevelCreator levelCreator, View view) {
        this.levelCreator = levelCreator;
        this.view = view;
        scanner = new Scanner(inputStream);
    }
    
    public void launch() throws Throwable {
        getUserInputs();
        createLevelInstance();
        createLevelFile();
    }
    
    private void getUserInputs() {
        while (true) {
            try {
                mapFileRequest();
                levelNameRequest();
                difficultyRequest();
                return;
            }
            
            catch (Exception e) {
                view.renderMessage(errorMessage);
                errorMessage = null;
            }
        }
    }
    
    private void mapFileRequest() throws Exception {
        try {
            if (mapFile == null) {
                listMapFiles();
                String userInput = view.request(view.MAP_FILE_REQUEST, scanner);
                int choice = Integer.parseInt(userInput);
                mapFile = mapFiles[choice];
                levelCreator.setMapFile(mapFile);
            }
            
        } catch (Exception e) {
            mapFile = null;
            errorMessage = e.toString();
            throw new Exception();
        }
    }
    
    private void levelNameRequest() throws Exception {
        try {
            if (levelName == null) {
                levelName = view.request(view.LEVEL_NAME_REQUEST, scanner);
                levelCreator.validateFileName(levelName);
            }
        } catch (Exception e) {
            levelName = null;
            errorMessage = e.toString();
            throw new Exception();
        }
    }
    
    private void difficultyRequest() throws Exception {
        try {
            listDifficulties();
            
            if (difficulty == null) {
                String userInput = view.request(view.LEVEL_DIFFICULTY_REQUEST, scanner);
                int choice = Integer.parseInt(userInput);
                difficulty = levelCreator.getDifficulty(choice);
            }
            
        } catch (Exception e) {
            difficulty = null;
            errorMessage = e.toString();
            throw new Exception();
        }
    }
    
    private void listDifficulties() {
        Difficulty[] difficulties = Difficulty.values();
        view.renderArray(difficulties);
    }
    
    private void createLevelInstance() throws Throwable {
        Map map = levelCreator.getMap();
        level = new Level(map, levelName, difficulty);
    }
    
    private void createLevelFile() throws Exception {
        String path = levelCreator.PWD + levelCreator.OUTPUT_MAP_DIR;
        LevelFileManager levelFileManager = new LevelFileManager(path);
        levelFileManager.createLevelFile(level);
    }
    
    private void listMapFiles() {
        mapFiles = levelCreator.getMapFiles();
        view.renderArray(mapFiles);
    }
}
