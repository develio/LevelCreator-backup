package levels.editor.levelCreator.model.exception;

public class MapFileException extends LevelCreatorException {
    private static final long serialVersionUID = 1L;
    
    @Override
    public String toString() {
        String message = "Couldn't find map file";
        return message;
    }
}
