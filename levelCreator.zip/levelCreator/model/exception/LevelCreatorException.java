package levels.editor.levelCreator.model.exception;

public abstract class LevelCreatorException extends Exception {
    private static final long serialVersionUID = 1L;
}
