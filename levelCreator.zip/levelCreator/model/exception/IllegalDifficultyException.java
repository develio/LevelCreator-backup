package levels.editor.levelCreator.model.exception;

public class IllegalDifficultyException extends LevelCreatorException {
    private static final long serialVersionUID = 1L;
    
    @Override
    public String toString() {
        String message = "Illegal difficulty";
        return message;
    }
}
