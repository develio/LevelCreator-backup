package levels.editor.levelCreator.model;

import java.awt.Dimension;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.IntStream;

import game.model.level.Difficulty;
import game.model.map.Map;
import game.model.map.block.Block;
import levels.editor.levelCreator.model.exception.IllegalDifficultyException;
import levels.editor.levelCreator.model.exception.IllegalFileNameException;
import levels.editor.levelCreator.model.exception.MapFileException;

public final class LevelCreator {
    public final String PWD = Paths.get("").toAbsolutePath().toString();
    public final String OUTPUT_MAP_DIR = "/src/levels/";
    private final String MAPS_DIR = "/src/levels/editor/maps/";
    private List<String> lines;
    private Dimension mapSize;
    
    public List<String> getMapFile() {
        return lines;
    }
    
    public void setMapFile(String input) throws MapFileException {
        try {
            String filename = String.format("%s%s%s", PWD, MAPS_DIR, input);
            File file = new File(filename);
            lines = Files.readAllLines(file.toPath());
        } catch (IOException e) {
            throw new MapFileException();
        }
    }
    
    public void validateFileName(String filename) throws IllegalFileNameException {
        String validFilename = "[A-Z][A-Z a-z]*";
        boolean validFileName = filename.matches(validFilename);
        
        if (!validFileName) {
            throw new IllegalFileNameException();
        }
    }
    
    public Difficulty getDifficulty(int value) throws IllegalDifficultyException {
        try {
            Difficulty difficulty = Difficulty.getByValue(value);
            return difficulty;
        } catch (IllegalArgumentException e) {
            throw new IllegalDifficultyException();
        }
    }
    
    public String[] getMapFiles() {
        File folder = new File(PWD + MAPS_DIR);
        File[] allFiles = folder.listFiles();
        ArrayList<String> files = new ArrayList<String>();
        String currentFile;
        
        for (File file : allFiles) {
            currentFile = file.getName();
            if (file.isFile() && !currentFile.equals(".DS_Store")) {
                files.add(currentFile);
            }
        }
        
        return files.toArray(new String[0]);
        
    }
    
    public Map getMap() throws Throwable {
        mapSize = getMapSize();
        Block[] blocks = getBlocks();
        Map map = new Map(blocks, mapSize.width);
        
        return map;
    }
    
    private Dimension getMapSize() {
        String[] dimStr = lines.get(0).replaceFirst(" tile_set", "").split(" ");
        return new Dimension(Integer.parseInt(dimStr[0]), Integer.parseInt(dimStr[1]));
    }
    
    private Block[] getBlocks() throws Throwable {
        int numberOfBlocks = mapSize.width * mapSize.height;
        Block[] blocks = new Block[numberOfBlocks];
        int currentBlock;
        int startIndex = 3;
        StringBuilder sb = new StringBuilder();
        IntStream.range(startIndex, lines.size()).forEach(i -> sb.append(lines.get(i)));
        String[] blocksStr = sb.toString().split(" ");
        
        for (int i = 0; i < numberOfBlocks; i++) {
            currentBlock = Integer.parseInt(blocksStr[i]);
            blocks[i] = BlockType.getBlockByValue(currentBlock);
        }
        
        return blocks;
    }
}
