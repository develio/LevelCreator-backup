package levels.editor.levelCreator.model;

import game.model.map.block.Block;
import game.model.map.block.Grass;
import game.model.map.block.VisitStatus;

public enum BlockType {
    NULL(0), APPLE(1), GRASS(2), PLAYER(3), STONE(4), GRASS_VISITED(5), WALL(6);
    
    private int value;
    
    private BlockType(int value) {
        this.value = value;
    }
    
    public int getValue() {
        return value;
    }
    
    public static Block getBlockByValue(int value) throws Throwable {
        BlockType[] blockTypes = BlockType.values();
        String className;
        String blockTypeName;
        Block block = null;
        String namespace = "game.model.map.block";
        
        for (BlockType blockType : blockTypes) {
            if (value == blockType.getValue()) {
                blockTypeName = blockType.name().toLowerCase();
                className = Character.toUpperCase(blockTypeName.charAt(0)) + blockTypeName.substring(1);
                
                if (className.equals("Grass_visited")) {
                    return new Grass(VisitStatus.VISITED);
                }
                
                block = (Block) Class.forName(namespace + "." + className).newInstance();
                break;
            }
        }
        
        return block;
    }
}
