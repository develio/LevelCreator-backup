package levels.editor.levelCreator.view;

import java.io.PrintStream;
import java.util.Scanner;
import java.util.stream.IntStream;

public final class View {
    private final PrintStream output;
    public final String MAP_FILE_REQUEST = "map file";
    public final String LEVEL_NAME_REQUEST = "level name";
    public final String LEVEL_DIFFICULTY_REQUEST = "difficulty";
    
    public View(PrintStream output) {
        this.output = output;
    }
    
    public String request(String message, Scanner input) {
        output.print(String.format("Enter %s: ", message));
        String userInput = input.nextLine();
        return userInput;
    }
    
    public void renderMessage(String message) {
        output.println(message);
    }
    
    public void renderArray(Object[] objects) {
        IntStream.range(0, objects.length).forEach(i -> output.println(String.format("%s (%s)", objects[i], i)));
    }
}
