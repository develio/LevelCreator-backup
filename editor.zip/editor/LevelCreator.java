package levels.editor;

import java.awt.Dimension;
import java.io.File;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;
import java.util.Scanner;

import game.model.level.Difficulty;
import game.model.level.Level;
import game.model.level.LevelFileManager;
import game.model.map.Map;
import game.model.map.block.Block;
import levels.editor.levelCreator.model.BlockType;

public class LevelCreator {
    private static int numberOfBlocks;
    private static String[] blocksStr;
    private static Scanner scanner = new Scanner(System.in);
    private final static String MAP_PATH = "/src/levels/editor/maps/";
    private static String mapDir = Paths.get("").toAbsolutePath().toString() + MAP_PATH;
    
    public static void main(String[] args) throws Throwable {
        String filename = inputRequest("Map filename: ");
        List<String> lines = Files.readAllLines(new File(mapDir + filename).toPath());
        Dimension mapSize = null;
        StringBuilder sb = new StringBuilder();
        
        for (int i = 0; i < lines.size(); i++) {
            if (i == 0) {
                mapSize = getSizeFromFirstLine(lines.get(i));
            }
            
            if (i < 3) {
                continue;
            }
            
            sb.append(lines.get(i));
        }
        
        numberOfBlocks = mapSize.width * mapSize.height;
        blocksStr = sb.toString().split(" ");
        
        String levelName = inputRequest("Level name: ");
        
        listDifficulties();
        Difficulty difficulty = Difficulty.getByValue(Integer.parseInt(inputRequest("Map filename: ")));
        
        String dir = inputRequest("Destination: ");
        
        LevelFileManager lfm = new LevelFileManager(dir);
        lfm.createLevelFile(new Level(new Map(getBlocks(), mapSize.width), levelName, difficulty));
        
        scanner.close();
    }
    
    private static Dimension getSizeFromFirstLine(String str) {
        String[] dimStr = str.replaceFirst(" tile_set", "").split(" ");
        return new Dimension(Integer.parseInt(dimStr[0]), Integer.parseInt(dimStr[1]));
    }
    
    private static Block[] getBlocks() throws Throwable {
        Block[] blocks = new Block[numberOfBlocks];
        int currentBlock;
        
        for (int i = 0; i < numberOfBlocks; i++) {
            currentBlock = Integer.parseInt(blocksStr[i]);
            blocks[i] = BlockType.getBlockByValue(currentBlock);
        }
        
        return blocks;
    }
    
    private static void listDifficulties() {
        Difficulty[] difficulties = Difficulty.values();
        
        for (int i = 0; i < difficulties.length; i++) {
            System.out.println(String.format("%s (%s)", difficulties[i], i));
        }
    }
    
    private static String inputRequest(String message) {
        System.out.print(message);
        return scanner.nextLine();
    }
}
