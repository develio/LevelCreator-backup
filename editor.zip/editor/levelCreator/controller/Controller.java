package levels.editor.levelCreator.controller;

import java.io.InputStream;
import java.util.Scanner;

import game.model.level.Difficulty;
import game.model.level.Level;
import game.model.level.LevelFileManager;
import game.model.map.Map;
import levels.editor.levelCreator.model.LevelCreator;
import levels.editor.levelCreator.model.exception.IllegalDifficultyException;
import levels.editor.levelCreator.model.exception.IllegalFileNameException;
import levels.editor.levelCreator.model.exception.MapFileException;
import levels.editor.levelCreator.view.View;

public final class Controller {
    private final LevelCreator levelCreator;
    private final View view;
    private final Scanner scanner;
    private final InputStream inputStream = System.in;
    private String mapFile = null;
    private String levelName = null;
    private Difficulty difficulty = null;
    private String errorMessage = null;
    private Level level = null;
    
    public Controller(LevelCreator levelCreator, View view) {
        this.levelCreator = levelCreator;
        this.view = view;
        scanner = new Scanner(inputStream);
    }
    
    public void launch() throws Throwable {
        getUserInputs();
        createLevelInstance();
        createLevelFile();
    }
    
    private void getUserInputs() {
        while (true) {
            try {
                mapFileRequest();
                levelNameRequest();
                listDifficulties();
                difficultyRequest();
                return;
            }
            
            catch (Exception e) {
                view.renderMessage(errorMessage);
                errorMessage = null;
            }
        }
    }
    
    private void mapFileRequest() throws Exception {
        try {
            mapFile = mapFile == null ? view.request(view.MAP_FILE_REQUEST, scanner) : mapFile;
            levelCreator.setMapFile(mapFile);
        } catch (MapFileException e) {
            mapFile = null;
            errorMessage = e.toString();
            throw new Exception();
        }
    }
    
    private void levelNameRequest() throws Exception {
        try {
            levelName = levelName == null ? view.request(view.LEVEL_NAME_REQUEST, scanner) : levelName;
            levelCreator.validateFileName(levelName);
        } catch (IllegalFileNameException e) {
            levelName = null;
            errorMessage = e.toString();
            throw new Exception();
        }
    }
    
    private void difficultyRequest() throws Exception {
        try {
            difficulty = difficulty == null
                    ? levelCreator.getDifficulty(Integer.parseInt(view.request(view.LEVEL_DIFFICULTY_REQUEST, scanner)))
                    : difficulty;
        } catch (NumberFormatException | IllegalDifficultyException e) {
            difficulty = null;
            errorMessage = e.toString();
            throw new Exception();
        }
    }
    
    private void listDifficulties() {
        Difficulty[] difficulties = Difficulty.values();
        view.renderArray(difficulties);
    }
    
    private void createLevelInstance() throws Throwable {
        Map map = levelCreator.getMap();
        level = new Level(map, levelName, difficulty);
    }
    
    private void createLevelFile() throws Exception {
        LevelFileManager levelFileManager = new LevelFileManager(levelCreator.PWD + levelCreator.OUTPUT_MAP_DIR);
        levelFileManager.createLevelFile(level);
    }
}
