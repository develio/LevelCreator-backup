package levels.editor.levelCreator;

import java.io.PrintStream;

import levels.editor.levelCreator.controller.Controller;
import levels.editor.levelCreator.model.LevelCreator;
import levels.editor.levelCreator.view.View;

public final class Program {
    private static PrintStream printStream = System.out;
    private static LevelCreator mapFileManager;
    private static View view;
    private static Controller controller;
    
    public static void main(String[] args) throws Throwable {
        initialize();
        controller.launch();
    }
    
    private static void initialize() {
        setMapFileManager();
        setView();
        setController();
    }
    
    private static void setMapFileManager() {
        mapFileManager = new LevelCreator();
    }
    
    private static void setView() {
        view = new View(printStream);
    }
    
    private static void setController() {
        controller = new Controller(mapFileManager, view);
    }
}
